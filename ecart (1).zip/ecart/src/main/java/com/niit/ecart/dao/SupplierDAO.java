package com.niit.ecart.dao;
import java.util.ArrayList;

import java.util.List;

import org.springframework.stereotype.Repository;
import com.niit.ecart.bean.Supplier;


@Repository

public class SupplierDAO {
public List<Supplier> getAllSuppliers(){
		
		List<Supplier> list = new ArrayList<Supplier>();
		Supplier s1= new Supplier();
		s1.setId("SUP_MOB");
		s1.setName("Sageetha");
		s1.setAddress("Chennai");
		list.add(s1);
		
		
		s1= new Supplier();
		s1.setId("SUP_EL");
		s1.setName("Chroma");
		s1.setAddress("Bangalore");
		list.add(s1);
		
		
		s1= new Supplier();
		s1.setId("SUP_HK");
		s1.setName("StarBazar");
		s1.setAddress("Hyderabad");
		list.add(s1);
		return list;
		
		
	}


}
